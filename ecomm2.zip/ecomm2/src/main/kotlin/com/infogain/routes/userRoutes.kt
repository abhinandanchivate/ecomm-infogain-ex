package com.infogain.routes

import com.infogain.payload.request.UserRequestPayload
import com.infogain.service.UserService
import com.infogain.utils.validate
import io.ktor.http.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.util.*

fun Route.userRoutes(userService: UserService) {
    route("/users") {
        post {
            val payload = call.receive<UserRequestPayload>().apply { validate() }
            // check duplicate email id .

            call.respond(HttpStatusCode.Created, userService.create(payload))
        }
        get { call.respond(userService.findAll()) }
        get("/{id}") {
            val id = call.parameters["id"]!!
            call.respond(userService.findById(id))
        }
        put("/{id}") {
            val id = call.parameters["id"]!!
            val payload = call.receive<UserRequestPayload>()
            println("payload data ${payload}")
            call.respond(userService.update(id, payload))
        }
        delete("/{id}") {
            val id = call.parameters["id"]!!
            println ("id value ${id}")
            call.respond(HttpStatusCode.NoContent, userService.delete(id))
        }
    }
}

