package com.infogain.di

import com.infogain.repository.RoleRepository
import com.infogain.repository.UserRepository
import com.infogain.service.RoleService
import com.infogain.service.UserService
import com.infogain.service.impl.RoleServiceImpl
import com.infogain.service.impl.UserServiceImpl
import org.kodein.di.DI
import org.kodein.di.bind
import org.kodein.di.instance
import org.kodein.di.singleton

val serviceModule = DI.Module("ServiceModule") {
    // type based
    bind<UserService>() with singleton { UserServiceImpl(instance<UserRepository>()) }
    bind<RoleService>() with singleton { RoleServiceImpl(instance<RoleRepository>()) }
}
/*
multiple availability with tag name

val serviceModule = DI.Module("ServiceModule") {
    // Bind UserService using the database implementation of UserRepository
    bind<UserService>() with singleton {
        UserServiceImpl(instance(tag = "database")) // Resolve repository using tag
    }

    // Bind RoleService using the in-memory implementation of RoleRepository
    bind<RoleService>() with singleton {
        RoleServiceImpl(instance(tag = "inMemory")) // Resolve repository using tag
    }
}

 */